package com.ultron.ai

import android.util.Xml
import java.net.URL

/** Step 7: top headlines via Google News RSS — free, no API key needed. */
object NewsHelper {

    /** [onResult] runs on a background thread. */
    fun getTopHeadlines(onResult: (String) -> Unit) {
        Thread {
            try {
                val xml = URL("https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en").readText()
                val titles = parseTitles(xml).take(4)
                if (titles.isEmpty()) {
                    onResult("Abhi news nahi mil payi")
                } else {
                    onResult("Aaj ki khabrein: " + titles.joinToString(". "))
                }
            } catch (e: Exception) {
                onResult("News laane me dikkat aayi: ${e.message}")
            }
        }.start()
    }

    private fun parseTitles(xml: String): List<String> {
        val titles = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(xml.reader())
        var eventType = parser.eventType
        var insideItem = false
        var isFirstTitleOfItem = true
        while (eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> {
                    if (parser.name == "item") { insideItem = true; isFirstTitleOfItem = true }
                    if (insideItem && parser.name == "title" && isFirstTitleOfItem) {
                        val text = parser.nextText()
                        titles.add(text)
                        isFirstTitleOfItem = false
                    }
                }
                org.xmlpull.v1.XmlPullParser.END_TAG -> {
                    if (parser.name == "item") insideItem = false
                }
            }
            eventType = parser.next()
        }
        return titles
    }
}
