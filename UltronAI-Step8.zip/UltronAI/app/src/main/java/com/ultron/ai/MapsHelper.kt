package com.ultron.ai

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Step 7: opens Google Maps navigation to a named destination. */
object MapsHelper {
    fun navigateTo(context: Context, destination: String): String {
        return try {
            val uri = Uri.parse("google.navigation:q=${Uri.encode(destination)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$destination ka rasta dikha raha hoon"
        } catch (e: Exception) {
            try {
                val geoUri = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
                context.startActivity(Intent(Intent.ACTION_VIEW, geoUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "$destination dhoondh raha hoon Maps me"
            } catch (e2: Exception) {
                "Maps nahi khul paya: ${e2.message}"
            }
        }
    }
}
