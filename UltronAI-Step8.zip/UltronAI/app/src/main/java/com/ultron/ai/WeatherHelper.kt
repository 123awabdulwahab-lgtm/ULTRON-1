package com.ultron.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.URL

/** Step 7: current weather, using the phone's last known location and the
 *  free Open-Meteo API (no API key needed). */
object WeatherHelper {

    private fun weatherCodeToText(code: Int): String = when (code) {
        0 -> "Saaf aasman"
        1, 2, 3 -> "Halka baadal"
        45, 48 -> "Kohra"
        51, 53, 55 -> "Halki boondabaandi"
        61, 63, 65 -> "Baarish"
        71, 73, 75 -> "Barfbaari"
        80, 81, 82 -> "Tez baarish ke jhonke"
        95, 96, 99 -> "Toofan/garaj ke saath baarish"
        else -> "Mausam ka haal"
    }

    /** [onResult] runs on a background thread. */
    fun getCurrentWeather(context: Context, onResult: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            onResult("Location permission nahi hai — app kholke woh allow karo pehle")
            return
        }

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val location = try {
            lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        } catch (e: SecurityException) {
            null
        }

        if (location == null) {
            onResult("Abhi location nahi mil payi — ek baar Maps ya GPS khol ke phir try karo")
            return
        }

        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}" +
                        "&longitude=${location.longitude}&current_weather=true"
                )
                val response = url.readText()
                val json = JSONObject(response)
                val current = json.getJSONObject("current_weather")
                val temp = current.getDouble("temperature")
                val code = current.getInt("weathercode")
                onResult("Abhi ${temp.toInt()}°C hai, ${weatherCodeToText(code)}")
            } catch (e: Exception) {
                onResult("Mausam pata nahi kar paya: ${e.message}")
            }
        }.start()
    }
}
