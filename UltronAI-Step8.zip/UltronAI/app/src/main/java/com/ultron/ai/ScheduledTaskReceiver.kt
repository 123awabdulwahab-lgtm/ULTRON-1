package com.ultron.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ScheduledTaskReceiver : BroadcastReceiver() {
    companion object {
        const val EXTRA_COMMAND = "scheduled_command"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val command = intent.getStringExtra(EXTRA_COMMAND) ?: return
        val serviceContext = UltronAccessibilityService.instance
        if (serviceContext == null) {
            // Accessibility service not running right now — nothing we can
            // safely automate with, so just let the user know via notification.
            NotifyHelper.show(context, "Ultron (scheduled)", "'$command' chalana tha, par Accessibility Service on nahi hai")
            return
        }
        CommandRouter.handle(serviceContext, command) { result ->
            NotifyHelper.show(context, "Ultron (scheduled)", result)
            val speakIntent = Intent(context, AnnounceService::class.java).apply {
                putExtra(AnnounceService.EXTRA_TEXT, result)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(speakIntent)
            else context.startService(speakIntent)
        }
    }
}
