package com.ultron.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apiKeyInput = findViewById<EditText>(R.id.api_key_input)
        ApiKeyStore.get(this)?.let { apiKeyInput.setText(it) }

        findViewById<Button>(R.id.btn_save_key).setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            if (key.isBlank()) {
                Toast.makeText(this, "Pehle apni API key type karo", Toast.LENGTH_SHORT).show()
            } else {
                ApiKeyStore.save(this, key)
                Toast.makeText(this, "API key save ho gayi", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_grant_overlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_grant_accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(
                this,
                "Find 'Ultron AI' in the list and turn it ON",
                Toast.LENGTH_LONG
            ).show()
        }

        findViewById<Button>(R.id.btn_grant_mic).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.RECORD_AUDIO), 101
                )
            } else {
                Toast.makeText(this, "Microphone permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_ignore_battery).setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Already battery-optimization free hai", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_grant_location).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
                    102
                )
            } else {
                Toast.makeText(this, "Location permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_grant_contacts_call).setOnClickListener {
            val needed = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_CONTACTS)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.CALL_PHONE)
            if (needed.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, needed.toTypedArray(), 103)
            } else {
                Toast.makeText(this, "Contacts/Call permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_grant_exact_alarm).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
                if (!am.canScheduleExactAlarms()) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                } else {
                    Toast.makeText(this, "Exact alarm already allowed", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Is Android version me alag se allow karne ki zaroorat nahi", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_notification_access).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            Toast.makeText(
                this,
                "Find 'Ultron AI' in the list and turn it ON — yeh auto-reply ke liye chahiye",
                Toast.LENGTH_LONG
            ).show()
        }

        val autoReplySwitch = findViewById<Switch>(R.id.switch_auto_reply)
        autoReplySwitch.isChecked = AutoReplyPrefs.isEnabled(this)
        autoReplySwitch.setOnCheckedChangeListener { _, isChecked ->
            AutoReplyPrefs.setEnabled(this, isChecked)
            Toast.makeText(
                this,
                if (isChecked) "Auto-reply ON — WhatsApp messages ka khud jawab dega"
                else "Auto-reply OFF",
                Toast.LENGTH_SHORT
            ).show()
        }

        val aboutMeInput = findViewById<EditText>(R.id.about_me_input)
        aboutMeInput.setText(AutoReplyPrefs.getAboutMe(this))
        findViewById<Button>(R.id.btn_save_about_me).setOnClickListener {
            AutoReplyPrefs.setAboutMe(this, aboutMeInput.text.toString().trim())
            Toast.makeText(this, "Note save ho gaya", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btn_start_bubble).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay permission first (step 1)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Ultron is running in the background", Toast.LENGTH_SHORT).show()
        }
    }
}
