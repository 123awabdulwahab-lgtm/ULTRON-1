package com.ultron.ai

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Floating round "Ultron" icon that sits on top of every app.
 * Tap it -> a small command box appears with a text field AND a mic button
 * (Step 4). Type or speak a command, and CommandRouter + the accessibility
 * service carry it out, with Ultron speaking the result back (male voice).
 * Drag the bubble to move it anywhere on screen.
 */
class FloatingBubbleService : Service(), TextToSpeech.OnInitListener {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var commandBoxView: View? = null
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val CHANNEL_ID = "ultron_bubble_channel"
    private val NOTIF_ID = 1001

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        startForeground(NOTIF_ID, buildNotification())
        showBubble()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            // Look for the deepest / most "male"-labelled voice the device offers.
            tts?.voices?.firstOrNull { v ->
                v.name.contains("male", ignoreCase = true) && !v.isNetworkConnectionRequired
            }?.let { tts?.voice = it }
            tts?.setPitch(0.9f)      // slightly deeper
            tts?.setSpeechRate(1.0f)
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Ultron AI running", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Ultron AI")
            .setContentText("Running in the background")
            .setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .setOngoing(true)
            .build()
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        windowManager.addView(bubbleView, params)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDrag = false

        bubbleView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) isDrag = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(bubbleView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDrag) toggleCommandBox(params)
                    true
                }
                else -> false
            }
        }
    }

    private val mainHandler = android.os.Handler(Looper.getMainLooper())

    private fun toggleCommandBox(bubbleParams: WindowManager.LayoutParams) {
        if (commandBoxView != null) {
            hideCommandBox()
            return
        }
        speak("Hello boss")

        val box = LayoutInflater.from(this).inflate(R.layout.floating_command_box, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUS_BEFORE_NAVIGATION,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams.x
        params.y = bubbleParams.y + 70

        val input = box.findViewById<EditText>(R.id.command_input)
        val sendBtn = box.findViewById<Button>(R.id.command_send)
        val micBtn = box.findViewById<Button>(R.id.command_mic)

        val submit = {
            val text = input.text.toString()
            if (text.isNotBlank()) {
                Toast.makeText(this, "Soch raha hoon...", Toast.LENGTH_SHORT).show()
                CommandRouter.handle(this, text) { response ->
                    mainHandler.post {
                        Toast.makeText(this, response, Toast.LENGTH_LONG).show()
                        speak(response)
                    }
                }
            }
            hideCommandBox()
        }

        sendBtn.setOnClickListener { submit() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submit(); true
            } else false
        }
        micBtn.setOnClickListener { startListening(input, submit) }

        windowManager.addView(box, params)
        commandBoxView = box
    }

    /** Step 4: speech-to-text, using the device's built-in recognizer directly
     *  (no separate popup screen — fits the "just a bubble" style Ultron uses). */
    private fun startListening(input: EditText, submit: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(
                this, "Pehle app kholke microphone permission allow karo", Toast.LENGTH_LONG
            ).show()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone me speech recognition available nahi hai", Toast.LENGTH_LONG).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: android.os.Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()
                    if (!text.isNullOrBlank()) {
                        input.setText(text)
                        submit()
                    } else {
                        Toast.makeText(this@FloatingBubbleService, "Kuch sunayi nahi diya", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onError(error: Int) {
                    Toast.makeText(this@FloatingBubbleService, "Sunne me dikkat aayi, phir try karo", Toast.LENGTH_SHORT).show()
                }
                override fun onReadyForSpeech(params: android.os.Bundle?) {
                    Toast.makeText(this@FloatingBubbleService, "Bolo...", Toast.LENGTH_SHORT).show()
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun hideCommandBox() {
        commandBoxView?.let { windowManager.removeView(it) }
        commandBoxView = null
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ultron_speak")
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { windowManager.removeView(it) }
        hideCommandBox()
        tts?.stop()
        tts?.shutdown()
    }
}
