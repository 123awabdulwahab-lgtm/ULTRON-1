package com.ultron.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * The AI brain — uses Google's Gemini API (free tier, no card needed).
 *
 * Two jobs:
 *  1. interpretPlan() — Step 8 Planner: turns a free-form command (simple
 *     OR multi-step, e.g. "ammi ko message karo aur phir mausam batao")
 *     into an ordered list of ActionSteps for CommandRouter to execute.
 *  2. generateReply() — WhatsApp auto-reply: turns an incoming message
 *     into a short natural reply, written as if the user sent it.
 */
object AiBrain {

    private const val MODEL = "gemini-2.0-flash"
    private fun apiUrl(apiKey: String) =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"

    private const val PLAN_SYSTEM_PROMPT = """
You are the planning brain for "Ultron", an Android on-device assistant.
The user will type/speak a short instruction in Hindi, English, or a mix.

Break it into a JSON ARRAY of one or more steps needed to fully complete
it, in the order they should run. Even a single-action request must still
be wrapped in an array with one element. Reply with ONLY the raw JSON
array — no markdown fences, no explanation.

Each step is one of:
{"action": "open", "value": "<app name>"}
{"action": "click", "value": "<visible text of the button/link to tap>"}
{"action": "type", "value": "<text to type into the focused field>"}
{"action": "message", "contact": "<person's name>", "value": "<WhatsApp message text>"}
{"action": "weather"}
{"action": "remind", "value": "<what to remind about>", "minutes_from_now": <integer>}
{"action": "call", "contact": "<person's name>"}
{"action": "news"}
{"action": "directions", "value": "<destination place name>"}
{"action": "media", "value": "play_pause" | "next" | "previous"}
{"action": "browse", "value": "<url, or a search query>"}
{"action": "read_screen"}
{"action": "remember", "value": "<fact to remember long-term>"}
{"action": "skill_save", "name": "<short skill name>", "value": "<the full instruction this skill should run, in the user's own words>"}
{"action": "skill_run", "name": "<skill name>"}
{"action": "schedule_task", "value": "<the command to run later, in plain words>", "minutes_from_now": <integer>}
{"action": "schedule_repeating", "value": "<the command to run repeatedly>", "interval_minutes": <integer>}
{"action": "back"}
{"action": "home"}
{"action": "recents"}
{"action": "speak", "value": "<short reply — chit-chat, questions, quick maths>"}

Rules:
- Multi-step requests ("X karo aur phir Y bhi karo") become multiple steps in order.
- "message" needs both contact and value; if no message content was given, still emit it with an empty value.
- "remind" is for a short spoken note later; "schedule_task"/"schedule_repeating" are for re-running a REAL command later (open/click/message/weather/etc) — use these when the user wants an app action repeated or delayed, not just reminded.
- "skill_save" is for "isko yaad rakho ki jab main bolu X to Y karna" style requests — store the FULL instruction as value.
- "skill_run" is for "X karo" when X matches a previously saved skill name.
- "remember" is for standalone facts to keep long-term (not tied to any action), e.g. "yaad rakho meri car ka number XYZ hai".
- "speak" is for chit-chat, general questions, and arithmetic — compute the answer yourself.
"""

    /** Free-form command -> ordered plan. [onResult] runs on a background
     *  thread — hop to the main thread before touching UI. [memoryContext]
     *  is optional remembered-facts text to give the planner extra context. */
    fun interpretPlan(
        command: String,
        apiKey: String,
        memoryContext: String,
        onResult: (List<ActionStep>) -> Unit,
        onError: (String) -> Unit
    ) {
        val prompt = if (memoryContext.isBlank()) PLAN_SYSTEM_PROMPT else "$PLAN_SYSTEM_PROMPT\n\n$memoryContext"
        callGemini(prompt, command, apiKey, onText = { text ->
            try {
                val cleaned = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                val arr = JSONArray(cleaned)
                val steps = (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    ActionStep(
                        action = o.getString("action"),
                        value = if (o.has("value")) o.getString("value") else null,
                        contact = if (o.has("contact")) o.getString("contact") else null,
                        minutesFromNow = if (o.has("minutes_from_now")) o.getInt("minutes_from_now") else null,
                        intervalMinutes = if (o.has("interval_minutes")) o.getInt("interval_minutes") else null,
                        name = if (o.has("name")) o.getString("name") else null
                    )
                }
                onResult(steps)
            } catch (e: Exception) {
                onError("AI ka plan samajh nahi paya: ${e.message}")
            }
        }, onError = onError)
    }

    /** WhatsApp auto-reply: writes a short natural reply on the user's
     *  behalf. [onResult] runs on a background thread. */
    fun generateReply(
        senderName: String,
        incomingMessage: String,
        aboutMe: String,
        apiKey: String,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val systemPrompt = """
You are ghost-writing a WhatsApp reply on behalf of a phone's owner, whose
own notes about themself are: "$aboutMe"
Someone named "$senderName" just messaged them. Write ONE short, natural
reply (1-2 sentences, same language/script as the incoming message —
Hindi, Hinglish or English). No quotes, no labels — just the reply text.
"""
        callGemini(systemPrompt, incomingMessage, apiKey, onText = { onResult(it.trim().trim('"')) }, onError = onError)
    }

    private fun callGemini(
        systemPrompt: String,
        userText: String,
        apiKey: String,
        onText: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                val url = URL(apiUrl(apiKey))
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("content-type", "application/json")
                conn.doOutput = true

                val body = JSONObject().apply {
                    put("system_instruction", JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                    })
                    put("contents", JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", userText)))
                        }
                    ))
                }

                val os: OutputStream = conn.outputStream
                os.write(body.toString().toByteArray(Charsets.UTF_8))
                os.close()

                val code = conn.responseCode
                if (code !in 200..299) {
                    val err = conn.errorStream?.bufferedReader()?.readText() ?: "HTTP $code"
                    onError("AI se baat nahi ho payi: $err")
                    return@Thread
                }

                val responseText = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(responseText)
                val text = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()

                onText(text)
            } catch (e: Exception) {
                onError("AI brain me dikkat aayi: ${e.message}")
            }
        }.start()
    }
}
