package com.ultron.ai

/** One step of a plan. The AI brain returns a list of these (1 step for a
 *  simple command, several for a multi-step request); CommandRouter (the
 *  Planner/Executor) runs them one at a time. */
data class ActionStep(
    val action: String,
    val value: String? = null,
    val contact: String? = null,
    val minutesFromNow: Int? = null,
    val intervalMinutes: Int? = null,
    val name: String? = null
)
