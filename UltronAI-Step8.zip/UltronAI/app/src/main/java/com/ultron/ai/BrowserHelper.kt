package com.ultron.ai

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Step 8 — Browser Agent.
 * Opens the phone's default browser to a URL or a search. Once open, the
 * SAME generic "click <text>" / "type <text>" / "read screen" actions
 * (already built for automating any app) work on the browser too — a
 * webpage's visible text and buttons show up in the accessibility tree
 * just like any other app's, so no separate DOM engine is needed for
 * simple pages.
 */
object BrowserHelper {

    fun open(context: Context, target: String): String {
        val looksLikeUrl = target.contains(".") && !target.contains(" ")
        val url = if (looksLikeUrl) {
            if (target.startsWith("http")) target else "https://$target"
        } else {
            "https://www.google.com/search?q=${Uri.encode(target)}"
        }
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            if (looksLikeUrl) "$target khol raha hoon" else "'$target' search kar raha hoon"
        } catch (e: Exception) {
            "Browser nahi khul paya: ${e.message}"
        }
    }
}
