package com.ultron.ai

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock

/** Step 7: schedules a reminder [minutesFromNow] minutes in the future. */
object ReminderHelper {

    fun schedule(context: Context, text: String, minutesFromNow: Int): String {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_TEXT, text)
        }
        val requestCode = System.currentTimeMillis().toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAt = SystemClock.elapsedRealtime() + minutesFromNow * 60_000L

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent)
                "$minutesFromNow minute me yaad dila dunga (exact alarm permission nahi hai, thoda time aage-peeche ho sakta hai)"
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent)
                "Theek hai, $minutesFromNow minute me yaad dila dunga: $text"
            }
        } catch (e: Exception) {
            "Reminder set nahi kar paya: ${e.message}"
        }
    }
}
