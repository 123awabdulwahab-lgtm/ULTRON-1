package com.ultron.ai

import android.content.Context

/**
 * Step 8 — Tool Engine.
 * Every action Ultron can perform lives here as one "tool", each reporting
 * back (success, message) — the success flag is what CommandRouter's
 * Verifier/Self-Recovery logic uses to decide whether to retry a step.
 */
object ToolRegistry {

    /** [onDone] may be called synchronously or later (async tools like
     *  message/weather/news) — always on the main thread. */
    fun run(context: Context, service: UltronAccessibilityService, step: ActionStep, onDone: (Boolean, String) -> Unit) {
        when (step.action) {
            "back" -> ok(onDone, service.pressBack(), "Theek hai, back ja raha hoon", "Back nahi kar paya")
            "home" -> ok(onDone, service.pressHome(), "Home screen par ja raha hoon", "Home nahi kar paya")
            "recents" -> ok(onDone, service.openRecents(), "Recent apps khol raha hoon", "Recents nahi khul paya")

            "open" -> {
                val app = step.value
                if (app == null) return onDone(false, "Kaunsa app, yeh nahi bataya")
                ok(onDone, service.openApp(app), "$app khol raha hoon", "'$app' naam ka app nahi mila")
            }
            "click" -> {
                val label = step.value
                if (label == null) return onDone(false, "Kis par click karna hai, yeh nahi bataya")
                ok(onDone, service.clickByText(label), "'$label' par tap kar diya", "'$label' screen par nahi dikha")
            }
            "type" -> {
                val text = step.value
                if (text == null) return onDone(false, "Kya type karna hai, yeh nahi bataya")
                ok(onDone, service.typeIntoFocused(text), "Type kar diya: $text", "Koi text box focus me nahi hai")
            }
            "message" -> {
                val who = step.contact
                val text = step.value
                if (who == null) return onDone(false, "Kisko message karna hai, yeh nahi bataya")
                if (text.isNullOrBlank()) {
                    return onDone(false, "$who ko kya likhna hai? Poori command ek saath bolo")
                }
                service.sendWhatsAppMessage(who, text) { result ->
                    onDone(!result.contains("nahi"), result)
                }
            }
            "weather" -> WeatherHelper.getCurrentWeather(context) { result -> onDone(!result.contains("nahi"), result) }
            "news" -> NewsHelper.getTopHeadlines { result -> onDone(!result.contains("dikkat") && !result.contains("nahi mil"), result) }
            "call" -> {
                val who = step.contact ?: return onDone(false, "Kisko call karna hai, yeh nahi bataya")
                val result = CallHelper.call(context, who)
                onDone(!result.contains("nahi"), result)
            }
            "remind" -> {
                val text = step.value ?: "Reminder"
                val minutes = step.minutesFromNow ?: 5
                val result = ReminderHelper.schedule(context, text, minutes)
                onDone(!result.contains("nahi"), result)
            }
            "schedule_task" -> {
                val cmd = step.value ?: return onDone(false, "Kya schedule karna hai, yeh nahi bataya")
                val minutes = step.minutesFromNow ?: 5
                val result = ScheduledTaskHelper.scheduleOnce(context, cmd, minutes)
                onDone(!result.contains("nahi"), result)
            }
            "schedule_repeating" -> {
                val cmd = step.value ?: return onDone(false, "Kya repeat karna hai, yeh nahi bataya")
                val interval = step.intervalMinutes ?: 60
                val result = ScheduledTaskHelper.scheduleRepeating(context, cmd, interval)
                onDone(!result.contains("nahi"), result)
            }
            "directions" -> {
                val dest = step.value ?: return onDone(false, "Kahan jaana hai, yeh nahi bataya")
                val result = MapsHelper.navigateTo(context, dest)
                onDone(!result.contains("nahi"), result)
            }
            "media" -> onDone(true, MediaHelper.sendMediaKey(context, step.value ?: "play_pause"))
            "browse" -> {
                val target = step.value ?: return onDone(false, "Kya search/open karna hai, yeh nahi bataya")
                val result = BrowserHelper.open(context, target)
                onDone(!result.contains("nahi"), result)
            }
            "read_screen" -> {
                val description = ScreenReader.describe(service.rootInActiveWindow)
                onDone(true, description)
            }
            "remember" -> {
                val fact = step.value ?: return onDone(false, "Kya yaad rakhna hai, yeh nahi bataya")
                MemoryStore.remember(context, fact)
                onDone(true, "Yaad rakh liya: $fact")
            }
            "skill_save" -> {
                val name = step.name
                val steps = step.value
                if (name == null || steps.isNullOrBlank()) return onDone(false, "Skill ka naam ya steps clear nahi the")
                SkillStore.save(context, name, steps)
                onDone(true, "'$name' naam se yeh skill yaad rakh li")
            }
            "skill_run" -> {
                val name = step.name ?: return onDone(false, "Kaunsi skill chalani hai, yeh nahi bataya")
                val stored = SkillStore.get(context, name)
                if (stored == null) {
                    onDone(false, "'$name' naam ki koi skill save nahi mili")
                } else {
                    CommandRouter.handle(context, stored) { result -> onDone(true, result) }
                }
            }
            "speak" -> onDone(true, step.value ?: "Ji boss?")
            else -> onDone(false, "Yeh action samajh nahi paya: ${step.action}")
        }
    }

    private fun ok(onDone: (Boolean, String) -> Unit, success: Boolean, okMsg: String, failMsg: String) {
        onDone(success, if (success) okMsg else failMsg)
    }
}
