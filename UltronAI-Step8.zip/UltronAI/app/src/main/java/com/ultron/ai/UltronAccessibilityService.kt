package com.ultron.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * The real automation engine.
 *
 * Once the user turns this ON in Settings > Accessibility, Ultron can:
 *  - read what is on screen (find a button/text by its label)
 *  - tap it
 *  - type text into whatever is focused
 *  - press back / go home / open recents
 *  - open any installed app by name
 *  - Step 6: open WhatsApp, find a contact by name, type a message and send it
 *
 * A single running instance is kept in `instance` so other components (the
 * floating bubble, the notification listener) can call into it.
 */
class UltronAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "UltronAccessibility"
        var instance: UltronAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Ultron Accessibility Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We act on-demand (see functions below) rather than reacting to
        // every event, to keep behaviour predictable.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    // ---------- Simple automation primitives ----------

    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findNode(root, label)
        return target != null && performClickOnNode(target)
    }

    fun typeIntoFocused(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openApp(appName: String): Boolean {
        val pm = packageManager
        val launchIntents = pm.getInstalledApplications(0).mapNotNull { appInfo ->
            val label = pm.getApplicationLabel(appInfo).toString()
            if (label.contains(appName, ignoreCase = true)) pm.getLaunchIntentForPackage(appInfo.packageName)
            else null
        }
        val intent = launchIntents.firstOrNull() ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    // ---------- Step 6: compound "send a WhatsApp message" automation ----------
    //
    // This is a multi-screen action (open app -> find contact -> open chat ->
    // type -> send), and each screen takes a moment to load, so it retries a
    // few times with short delays instead of assuming the UI is instantly ready.

    /** Opens WhatsApp, finds [contact] by name, types [text] and sends it.
     *  [onDone] is called on the main thread with a human-readable result. */
    fun sendWhatsAppMessage(contact: String, text: String, onDone: (String) -> Unit) {
        if (!openApp("WhatsApp")) {
            onDone("WhatsApp is phone me nahi mila")
            return
        }
        handler.postDelayed({ findAndOpenContact(contact, text, onDone, attempt = 0) }, 1200)
    }

    private fun findAndOpenContact(contact: String, text: String, onDone: (String) -> Unit, attempt: Int) {
        val root = rootInActiveWindow
        val node = root?.let { findNode(it, contact) }
        if (node != null && performClickOnNode(node)) {
            handler.postDelayed({ typeAndSend(contact, text, onDone, attempt = 0) }, 1000)
        } else if (attempt < 15) {
            handler.postDelayed({ findAndOpenContact(contact, text, onDone, attempt + 1) }, 400)
        } else {
            onDone("'$contact' naam ka contact WhatsApp me nahi mila")
        }
    }

    private fun typeAndSend(contact: String, text: String, onDone: (String) -> Unit, attempt: Int) {
        val root = rootInActiveWindow
        val inputNode = root?.let { findFirstEditable(it) }
        if (inputNode != null) {
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            handler.postDelayed({
                val sendNode = rootInActiveWindow?.let { findNodeByDescription(it, "Send") }
                if (sendNode != null && performClickOnNode(sendNode)) {
                    onDone("$contact ko message bhej diya")
                } else {
                    onDone("$contact ke liye message likh diya, par Send button nahi mila — khud bhej dena")
                }
            }, 500)
        } else if (attempt < 15) {
            handler.postDelayed({ typeAndSend(contact, text, onDone, attempt + 1) }, 400)
        } else {
            onDone("$contact ki chat khuli par message box nahi mila")
        }
    }

    // ---------- Internal tree-search helpers ----------

    private fun findNode(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val byText = root.findAccessibilityNodeInfosByText(label)
        if (byText.isNotEmpty()) return byText[0]
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            if (child.contentDescription?.toString()?.contains(label, ignoreCase = true) == true) return child
            val found = findNode(child, label)
            if (found != null) return found
        }
        return null
    }

    private fun findNodeByDescription(root: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (root.contentDescription?.toString()?.equals(desc, ignoreCase = true) == true) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNodeByDescription(child, desc)
            if (found != null) return found
        }
        return null
    }

    private fun findFirstEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.className == "android.widget.EditText") return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findFirstEditable(child)
            if (found != null) return found
        }
        return null
    }

    private fun performClickOnNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            current = current.parent
        }
        return false
    }
}
