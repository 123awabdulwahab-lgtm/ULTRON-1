package com.ultron.ai

import android.content.Context

/**
 * Stores the user's own Gemini API key locally on the phone (SharedPreferences),
 * never in the code / GitHub repo. Entered once from MainActivity.
 */
object ApiKeyStore {
    private const val PREFS = "ultron_prefs"
    private const val KEY = "gemini_api_key"

    fun save(context: Context, apiKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, apiKey).apply()
    }

    fun get(context: Context): String? {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null)
    }
}
