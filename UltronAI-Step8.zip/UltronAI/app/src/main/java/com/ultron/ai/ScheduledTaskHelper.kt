package com.ultron.ai

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock

/**
 * Step 8 — Scheduler / Automation.
 * Unlike ReminderHelper (which just speaks a note), this actually RE-RUNS
 * a full command through CommandRouter later — e.g. "har roz subah mausam
 * batana" schedules the real "mausam batao" command to execute daily.
 */
object ScheduledTaskHelper {

    /** One-time, [minutesFromNow] minutes later. */
    fun scheduleOnce(context: Context, command: String, minutesFromNow: Int): String {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduledTaskReceiver::class.java).apply {
            putExtra(ScheduledTaskReceiver.EXTRA_COMMAND, command)
        }
        val requestCode = System.currentTimeMillis().toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAt = SystemClock.elapsedRealtime() + minutesFromNow * 60_000L
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent)
            }
            "Theek hai, $minutesFromNow minute me yeh karunga: $command"
        } catch (e: Exception) {
            "Schedule nahi kar paya: ${e.message}"
        }
    }

    /** Repeats roughly every [intervalMinutes] (Android batches inexact
     *  repeating alarms to save battery, so timing is approximate, not
     *  second-perfect — fine for "roughly every N minutes/hours" tasks). */
    fun scheduleRepeating(context: Context, command: String, intervalMinutes: Int): String {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduledTaskReceiver::class.java).apply {
            putExtra(ScheduledTaskReceiver.EXTRA_COMMAND, command)
        }
        val requestCode = command.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val intervalMs = intervalMinutes * 60_000L
        return try {
            alarmManager.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + intervalMs,
                intervalMs,
                pendingIntent
            )
            "Theek hai, har $intervalMinutes minute me (lagbhag) yeh karta rahunga: $command"
        } catch (e: Exception) {
            "Repeating schedule nahi kar paya: ${e.message}"
        }
    }
}
