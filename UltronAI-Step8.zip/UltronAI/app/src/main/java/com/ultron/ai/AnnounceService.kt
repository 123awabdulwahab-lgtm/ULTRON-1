package com.ultron.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.util.Locale

/** Speaks one piece of text out loud (e.g. a due reminder) then stops itself. */
class AnnounceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "ultron_announce"
    }

    private var tts: TextToSpeech? = null
    private var pendingText: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pendingText = intent?.getStringExtra(EXTRA_TEXT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Ultron speaking", NotificationManager.IMPORTANCE_MIN)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Ultron")
                .setContentText("Bol raha hoon...")
                .setSmallIcon(android.R.drawable.ic_menu_myplaces)
                .build()
            startForeground(2001, notif)
        }
        tts = TextToSpeech(this, this)
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { stopSelf() }
                override fun onError(utteranceId: String?) { stopSelf() }
            })
            tts?.speak(pendingText ?: "", TextToSpeech.QUEUE_FLUSH, null, "ultron_announce")
        } else {
            stopSelf()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
    }
}
