package com.ultron.ai

import android.content.Context
import org.json.JSONObject

/**
 * Step 8 — Skills System.
 * A "skill" is just a saved instruction (in the user's own words) under a
 * short name — e.g. save "good night" -> "lights off ka message ammi ko
 * bhejo aur alarm 7 baje ka laga do". Later saying "skill good night" (or
 * the AI recognising that intent) re-runs the same plan through the AI
 * brain again, so skills reuse the exact same planning/execution engine.
 */
object SkillStore {
    private const val PREFS = "ultron_prefs"
    private const val KEY = "skills"

    fun save(context: Context, name: String, steps: String) {
        val obj = getAll(context)
        obj.put(name.trim().lowercase(), steps)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, obj.toString()).apply()
    }

    fun get(context: Context, name: String): String? {
        val obj = getAll(context)
        val key = name.trim().lowercase()
        return if (obj.has(key)) obj.getString(key) else null
    }

    fun list(context: Context): List<String> {
        val obj = getAll(context)
        return obj.keys().asSequence().toList()
    }

    private fun getAll(context: Context): JSONObject {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return JSONObject()
        return try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
    }
}
