package com.ultron.ai

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent

/** Step 7: play/pause/next/previous for whatever media app is currently active. */
object MediaHelper {
    fun sendMediaKey(context: Context, action: String): String {
        val keyCode = when (action) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return when (action) {
            "next" -> "Agla gaana laga raha hoon"
            "previous" -> "Pichla gaana laga raha hoon"
            else -> "Play/pause kar diya"
        }
    }
}
