package com.ultron.ai

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Step 8 — Screen Understanding.
 * Walks the current accessibility tree and collects visible text/labels
 * into one summary. Used both as a user-facing "what's on my screen"
 * action, and internally by the Planner/Verifier to check whether a step
 * actually changed anything.
 */
object ScreenReader {

    fun describe(root: AccessibilityNodeInfo?, maxItems: Int = 40): String {
        if (root == null) return "Screen padh nahi paya"
        val found = LinkedHashSet<String>()
        collect(root, found, maxItems)
        if (found.isEmpty()) return "Screen par koi text nahi mila"
        return found.take(maxItems).joinToString(", ")
    }

    /** Lightweight fingerprint used by the verifier to detect "did the
     *  screen actually change after this action?". */
    fun fingerprint(root: AccessibilityNodeInfo?): Int {
        if (root == null) return 0
        val found = LinkedHashSet<String>()
        collect(root, found, 60)
        return found.joinToString("|").hashCode()
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableSet<String>, max: Int) {
        if (out.size >= max) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) {
            if (out.size >= max) return
            node.getChild(i)?.let { collect(it, out, max) }
        }
    }
}
