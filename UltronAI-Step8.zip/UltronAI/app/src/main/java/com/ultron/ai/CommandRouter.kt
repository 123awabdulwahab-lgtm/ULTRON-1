package com.ultron.ai

import android.content.Context
import android.os.Handler
import android.os.Looper

/**
 * Step 8 — Planner + Verifier + Self-Recovery.
 *
 * Fixed one-word patterns are still tried first (instant, no network).
 * Everything else goes to AiBrain (the Planner), which returns an ORDERED
 * LIST of steps — even a simple one-line command becomes a 1-step "plan".
 * Steps run one at a time through ToolRegistry (the Tool Engine); each
 * step's own success/failure IS the verification signal, and a failed
 * step gets ONE automatic retry (self-recovery) before moving on — the
 * whole plan doesn't abort just because one step had a hiccup.
 */
object CommandRouter {

    private val handler = Handler(Looper.getMainLooper())

    /** [onResult] is called once, with a combined summary of every step. */
    fun handle(context: Context, rawCommand: String, onResult: (String) -> Unit) {
        val service = UltronAccessibilityService.instance
        if (service == null) {
            onResult("Accessibility permission on nahi hai. Settings me jaake Ultron ko ON karo.")
            return
        }

        val fixed = tryFixedPattern(rawCommand)
        if (fixed != null) {
            ToolRegistry.run(context, service, fixed) { _, message -> onResult(message) }
            return
        }

        val apiKey = ApiKeyStore.get(context)
        if (apiKey.isNullOrBlank()) {
            onResult("Yeh command samajh nahi paya. Gemini API key daalo MainActivity me (Step 3 setup).")
            return
        }

        AiBrain.interpretPlan(
            command = rawCommand,
            apiKey = apiKey,
            memoryContext = MemoryStore.asPromptContext(context),
            onResult = { steps ->
                if (steps.isEmpty()) {
                    onResult("Koi action samajh nahi aaya")
                } else {
                    executePlan(context, service, steps, 0, mutableListOf(), onResult)
                }
            },
            onError = { onResult(it) }
        )
    }

    /** A handful of instant patterns that skip the AI entirely. */
    private fun tryFixedPattern(rawCommand: String): ActionStep? {
        val cmd = rawCommand.trim().lowercase()
        return when {
            cmd == "back" || cmd.contains("wapas jao") -> ActionStep("back")
            cmd == "home" || cmd.contains("home jao") -> ActionStep("home")
            cmd == "recents" || cmd.contains("recent apps") -> ActionStep("recents")
            cmd == "weather" || cmd == "mausam" -> ActionStep("weather")
            cmd == "news" -> ActionStep("news")
            cmd == "read screen" || cmd == "screen padho" -> ActionStep("read_screen")
            cmd.startsWith("open ") || cmd.startsWith("khol ") -> ActionStep("open", value = rawCommand.trim().substringAfter(" ").trim())
            cmd.startsWith("click ") || cmd.startsWith("tap ") || cmd.startsWith("dabao ") -> ActionStep("click", value = rawCommand.trim().substringAfter(" ").trim())
            cmd.startsWith("type ") || cmd.startsWith("likho ") -> ActionStep("type", value = rawCommand.trim().substringAfter(" ").trim())
            else -> null
        }
    }

    /** Runs [steps] one at a time (Executor), retrying a failed step once
     *  (Self-Recovery) before continuing to the next — a failure never
     *  aborts the whole plan, it's just noted in the final summary. */
    private fun executePlan(
        context: Context,
        service: UltronAccessibilityService,
        steps: List<ActionStep>,
        index: Int,
        log: MutableList<String>,
        onAllDone: (String) -> Unit
    ) {
        if (index >= steps.size) {
            onAllDone(log.joinToString(". "))
            return
        }
        val step = steps[index]
        ToolRegistry.run(context, service, step) { success, message ->
            if (success) {
                log.add(message)
                executePlan(context, service, steps, index + 1, log, onAllDone)
            } else {
                // Self-recovery: one retry after a short delay (covers the
                // very common "screen wasn't ready yet" case).
                handler.postDelayed({
                    ToolRegistry.run(context, service, step) { success2, message2 ->
                        log.add(if (success2) message2 else "$message2 (dobara try kiya, phir bhi nahi hua)")
                        executePlan(context, service, steps, index + 1, log, onAllDone)
                    }
                }, 700)
            }
        }
    }
}
