package com.ultron.ai

import android.content.Context
import org.json.JSONArray

/**
 * Step 8 — Memory System.
 * Simple durable fact-list ("yaad rakho ki...") stored on-device. Every
 * plan the AI brain makes is given the current fact list as context, so it
 * can use things like remembered aliases/preferences when deciding actions.
 */
object MemoryStore {
    private const val PREFS = "ultron_prefs"
    private const val KEY = "memory_facts"
    private const val MAX_FACTS = 50

    fun remember(context: Context, fact: String) {
        val facts = getAllFacts(context).toMutableList()
        facts.add(fact)
        while (facts.size > MAX_FACTS) facts.removeAt(0)
        val arr = JSONArray()
        facts.forEach { arr.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun getAllFacts(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun forgetAll(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    /** Short text block to paste into the AI's system prompt as context. */
    fun asPromptContext(context: Context): String {
        val facts = getAllFacts(context)
        if (facts.isEmpty()) return ""
        return "Known facts remembered about the user (use if relevant):\n" +
            facts.joinToString("\n") { "- $it" }
    }
}
